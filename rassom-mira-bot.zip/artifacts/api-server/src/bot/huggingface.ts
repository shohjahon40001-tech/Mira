import axios from "axios";
import { logger } from "../lib/logger.js";

const MAX_FILE_SIZE = 25 * 1024 * 1024;

export async function translateUzbekToEnglish(text: string): Promise<string> {
  try {
    const response = await axios.get<{
      responseData: { translatedText: string };
      responseStatus: number;
    }>("https://api.mymemory.translated.net/get", {
      params: { q: text, langpair: "uz|en" },
      timeout: 15000,
    });

    const translated = response.data?.responseData?.translatedText;
    if (translated && response.data?.responseStatus === 200) {
      return translated;
    }
    return text;
  } catch (err) {
    logger.warn({ err }, "Translation failed, using original text");
    return text;
  }
}

export async function generateImage(prompt: string): Promise<Buffer> {
  const qualityTags =
    "masterpiece, best quality, ultra detailed, sharp focus, professional photography, cinematic lighting, 8k resolution, photorealistic";

  const negTags =
    "blurry, low quality, bad anatomy, ugly, distorted, pixelated, watermark, text, logo, nsfw";

  const fullPrompt = `${prompt}, ${qualityTags}`;
  const encodedPrompt = encodeURIComponent(fullPrompt);
  const encodedNeg = encodeURIComponent(negTags);

  const seed = Math.floor(Math.random() * 9999999);

  const url =
    `https://image.pollinations.ai/prompt/${encodedPrompt}` +
    `?width=1280&height=1280` +
    `&model=flux-pro` +
    `&nologo=true` +
    `&enhance=true` +
    `&negative=${encodedNeg}` +
    `&seed=${seed}`;

  logger.info({ url: url.slice(0, 120) }, "Generating image");

  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 180000,
    headers: { "User-Agent": "RassomMiraBot/2.0" },
  });

  const buffer = Buffer.from(response.data as ArrayBuffer);

  if (buffer.length < 5000) {
    throw new Error("Rasm yaratishda xato yuz berdi, qaytadan urinib ko'ring");
  }

  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error(
      `Rasm hajmi ${(buffer.length / 1024 / 1024).toFixed(1)}MB bo'lib, 25MB limitdan oshdi`,
    );
  }

  return buffer;
}
