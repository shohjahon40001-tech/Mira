import TelegramBot from "node-telegram-bot-api";
import { logger } from "../lib/logger.js";
import { translateUzbekToEnglish, generateImage } from "./huggingface.js";
import {
  getOrCreateUser,
  getUser,
  decrementUserImages,
  getAllUsers,
  createPromoCode,
  usePromoCode,
  getRequiredChannels,
  addChannel,
  removeChannel,
  isAdmin,
  getStats,
} from "./storage.js";

const TELEGRAM_TOKEN = process.env["TELEGRAM_BOT_TOKEN"] ?? "";

function esc(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function balanceBar(count: number, max = 20): string {
  const filled = Math.min(count, max);
  const empty = max - filled;
  return "🟩".repeat(Math.ceil(filled / 2)) + "⬜".repeat(Math.ceil(empty / 2));
}

async function checkChannelSubscriptions(
  bot: TelegramBot,
  chatId: number,
): Promise<{ ok: boolean; notJoined: string[] }> {
  const channels = getRequiredChannels();
  if (channels.length === 0) return { ok: true, notJoined: [] };
  const notJoined: string[] = [];
  for (const ch of channels) {
    try {
      const member = await bot.getChatMember(ch.username, chatId);
      if (["left", "kicked"].includes(member.status)) notJoined.push(ch.username);
    } catch {
      notJoined.push(ch.username);
    }
  }
  return { ok: notJoined.length === 0, notJoined };
}

export function startBot(): void {
  if (!TELEGRAM_TOKEN) {
    logger.warn("TELEGRAM_BOT_TOKEN is not set, bot will not start");
    return;
  }

  const bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });
  logger.info("Telegram bot started (@rassom_mira_bot)");

  // ─── /start ───────────────────────────────────────────────────────────────
  bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const user = getOrCreateUser(chatId, msg.from?.username ?? "", msg.from?.first_name ?? "");
    const bar = balanceBar(user.imageCount);

    await bot.sendMessage(
      chatId,
      `╔══════════════════╗\n` +
      `    🎨 <b>RASSOM MIRA BOT</b>\n` +
      `╚══════════════════╝\n\n` +
      `Salom, <b>${esc(user.firstName)}</b>! 👋\n\n` +
      `O'zbek tilida tavsif yuboring — uni inglizchaga tarjima qilib, sun'iy intellekt yordamida <b>yuqori sifatli rasm</b> yarataman!\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `🖼  <b>Rasm balansi:</b>  ${user.imageCount} ta\n` +
      `${bar}\n` +
      `━━━━━━━━━━━━━━━━━━\n\n` +
      `✏️  <i>Misol: "quyosh botayotgan tog' manzarasi"</i>\n\n` +
      `📌 Buyruqlar:\n` +
      `┣ /balance — balans tekshirish\n` +
      `┣ /code XXXXX — promo-kod\n` +
      `┗ /help — yordam`,
      { parse_mode: "HTML" },
    );
  });

  // ─── /help ────────────────────────────────────────────────────────────────
  bot.onText(/\/help/, async (msg) => {
    const chatId = msg.chat.id;
    await bot.sendMessage(
      chatId,
      `╔══════════════════╗\n` +
      `       📌 <b>YORDAM</b>\n` +
      `╚══════════════════╝\n\n` +
      `<b>Qanday ishlaydi?</b>\n` +
      `1️⃣  O'zbek tilida tavsif yozing\n` +
      `2️⃣  Bot inglizchaga tarjima qiladi\n` +
      `3️⃣  AI yuqori sifatli rasm yaratadi\n` +
      `4️⃣  Tayyor rasm sizga yuboriladi\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `✏️  <b>Misol so'rovlar:</b>\n` +
      `• kechki shahar ko'chalari, yomg'ir\n` +
      `• bahor bog'i, kapalaklar va gullar\n` +
      `• kosmik kema yulduzlar orasida\n` +
      `• tog' cho'qqisida qor va quyosh\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `⚡ <b>Buyruqlar:</b>\n` +
      `┣ /balance — rasmlar qoldig'i\n` +
      `┣ /code XXXXX — promo-kod faollashtirish\n` +
      `┗ /help — ushbu yordam\n\n` +
      `⚠️  Rasm hajmi 25MB dan oshmasligiga kafolat beriladi`,
      { parse_mode: "HTML" },
    );
  });

  // ─── /balance ─────────────────────────────────────────────────────────────
  bot.onText(/\/balance/, async (msg) => {
    const chatId = msg.chat.id;
    const user = getOrCreateUser(chatId, msg.from?.username ?? "", msg.from?.first_name ?? "");
    const bar = balanceBar(user.imageCount);

    await bot.sendMessage(
      chatId,
      `╔══════════════════╗\n` +
      `      🖼  <b>BALANS</b>\n` +
      `╚══════════════════╝\n\n` +
      `${bar}\n` +
      `🟩 Qolgan:    <b>${user.imageCount} ta rasm</b>\n` +
      `📊 Yaratilgan: <b>${user.totalUsed} ta rasm</b>\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `${user.imageCount === 0 ? "❌ <b>Rasmlar tugadi!</b> Promo-kod orqali to'ldiring:\n/code XXXXX" : "✅ Siz rasm yaratishingiz mumkin!"}`,
      { parse_mode: "HTML" },
    );
  });

  // ─── /code ────────────────────────────────────────────────────────────────
  bot.onText(/\/code (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    getOrCreateUser(chatId, msg.from?.username ?? "", msg.from?.first_name ?? "");
    const code = match?.[1]?.trim() ?? "";
    const result = usePromoCode(code, chatId);

    if (result.success) {
      const bar = balanceBar(result.newTotal ?? 0);
      await bot.sendMessage(
        chatId,
        `╔══════════════════╗\n` +
        `  ✅ <b>KOD FAOLLASHTIRILDI</b>\n` +
        `╚══════════════════╝\n\n` +
        `🎁 Sizga <b>+${result.imagesAdded} ta</b> rasm qo'shildi!\n\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `${bar}\n` +
        `🖼  Jami qolgan: <b>${result.newTotal} ta rasm</b>\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `Davom eting — so'rovingizni yuboring! 🎨`,
        { parse_mode: "HTML" },
      );
    } else {
      await bot.sendMessage(
        chatId,
        `╔══════════════════╗\n` +
        `    ❌ <b>KOD XATOSI</b>\n` +
        `╚══════════════════╝\n\n` +
        `${esc(result.reason ?? "Noma'lum xato")}\n\n` +
        `To'g'ri kodni /code XXXXX ko'rinishida kiriting.`,
        { parse_mode: "HTML" },
      );
    }
  });

  // ─── /admin (panel) ───────────────────────────────────────────────────────
  bot.onText(/\/admin$/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) {
      await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q.");
      return;
    }
    const promo = createPromoCode(10);
    const channels = getRequiredChannels();
    const stats = getStats();
    const chList = channels.length > 0
      ? channels.map((c) => `  ┣ ${esc(c.name)} — ${esc(c.username)}`).join("\n")
      : "  ┗ Hozircha yo'q";

    await bot.sendMessage(
      chatId,
      `╔══════════════════╗\n` +
      `     🔑 <b>ADMIN PANEL</b>\n` +
      `╚══════════════════╝\n\n` +
      `✅ Yangi promo-kod:\n` +
      `┗ <code>${promo.code}</code>  (+10 rasm, 1 marta)\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `📊 <b>Statistika:</b>\n` +
      `  ┣ 👥 Foydalanuvchilar: <b>${stats.totalUsers}</b>\n` +
      `  ┣ 🖼  Jami rasmlar: <b>${stats.totalImages}</b>\n` +
      `  ┗ 🔑 Kodlar: <b>${stats.usedCodes}/${stats.totalCodes}</b>\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `📢 <b>Majburiy kanallar:</b>\n` +
      `${chList}\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `💡 <b>Buyruqlar:</b>\n` +
      `  ┣ /admin @username\n` +
      `  ┣ /addchannel @kanal Nom\n` +
      `  ┣ /removechannel @kanal\n` +
      `  ┣ /channels\n` +
      `  ┣ /stats\n` +
      `  ┗ /broadcast matn`,
      { parse_mode: "HTML" },
    );
  });

  // ─── /admin @username ─────────────────────────────────────────────────────
  bot.onText(/\/admin @?(\S+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) {
      await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q.");
      return;
    }
    const username = match?.[1]?.replace("@", "").toLowerCase() ?? "";
    const found = getAllUsers().find((u) => u.username.toLowerCase() === username);

    if (!found) {
      await bot.sendMessage(chatId,
        `❌ <code>@${esc(username)}</code> foydalanuvchisi topilmadi.`,
        { parse_mode: "HTML" });
      return;
    }

    const joinDate = new Date(found.joinDate).toLocaleDateString("uz-UZ");
    const bar = balanceBar(found.imageCount);
    await bot.sendMessage(
      chatId,
      `╔══════════════════╗\n` +
      `   👤 <b>FOYDALANUVCHI</b>\n` +
      `╚══════════════════╝\n\n` +
      `┣ Ism: <b>${esc(found.firstName)}</b>\n` +
      `┣ Username: @${esc(found.username)}\n` +
      `┣ Chat ID: <code>${found.chatId}</code>\n` +
      `┣ Ro'yxat: ${joinDate}\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `${bar}\n` +
      `┣ 🖼  Qolgan: <b>${found.imageCount} ta</b>\n` +
      `┣ 📊 Yaratilgan: <b>${found.totalUsed} ta</b>\n` +
      `┗ 🔑 Kodlar: ${found.usedCodes.length > 0 ? found.usedCodes.join(", ") : "yo'q"}`,
      { parse_mode: "HTML" },
    );
  });

  // ─── /addchannel ──────────────────────────────────────────────────────────
  bot.onText(/\/addchannel (@?\S+)(?: (.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) { await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q."); return; }
    const username = match?.[1] ?? "";
    const name = match?.[2] ?? username;
    const ok = addChannel(username, name);
    await bot.sendMessage(chatId,
      ok
        ? `✅ <b>${esc(name)}</b> (<code>${esc(username)}</code>) majburiy ro'yxatga qo'shildi.`
        : `⚠️ Bu kanal allaqachon ro'yxatda bor.`,
      { parse_mode: "HTML" });
  });

  // ─── /removechannel ───────────────────────────────────────────────────────
  bot.onText(/\/removechannel (@?\S+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) { await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q."); return; }
    const username = match?.[1] ?? "";
    const ok = removeChannel(username);
    await bot.sendMessage(chatId,
      ok ? `✅ <code>${esc(username)}</code> ro'yxatdan o'chirildi.`
         : `❌ <code>${esc(username)}</code> topilmadi.`,
      { parse_mode: "HTML" });
  });

  // ─── /channels ────────────────────────────────────────────────────────────
  bot.onText(/\/channels/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) { await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q."); return; }
    const channels = getRequiredChannels();
    if (channels.length === 0) { await bot.sendMessage(chatId, "📭 Hozircha majburiy kanallar yo'q."); return; }
    const list = channels.map((c, i) => `${i + 1}. <b>${esc(c.name)}</b> — ${esc(c.username)}`).join("\n");
    await bot.sendMessage(chatId,
      `📢 <b>Majburiy kanallar:</b>\n\n${list}`,
      { parse_mode: "HTML" });
  });

  // ─── /stats ───────────────────────────────────────────────────────────────
  bot.onText(/\/stats/, async (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) { await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q."); return; }
    const stats = getStats();
    const topUsers = [...getAllUsers()].sort((a, b) => b.totalUsed - a.totalUsed).slice(0, 5);
    const topList = topUsers.length > 0
      ? topUsers.map((u, i) => `  ${i + 1}. @${esc(u.username)} — ${u.totalUsed} ta`).join("\n")
      : "  Hali yo'q";
    await bot.sendMessage(chatId,
      `╔══════════════════╗\n` +
      `     📊 <b>STATISTIKA</b>\n` +
      `╚══════════════════╝\n\n` +
      `┣ 👥 Foydalanuvchilar: <b>${stats.totalUsers}</b>\n` +
      `┣ 🖼  Jami rasmlar: <b>${stats.totalImages}</b>\n` +
      `┗ 🔑 Kodlar: <b>${stats.usedCodes}/${stats.totalCodes}</b>\n\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `🏆 <b>Top foydalanuvchilar:</b>\n${topList}`,
      { parse_mode: "HTML" });
  });

  // ─── /broadcast ───────────────────────────────────────────────────────────
  bot.onText(/\/broadcast (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) { await bot.sendMessage(chatId, "❌ Sizda admin huquqi yo'q."); return; }
    const text = match?.[1] ?? "";
    const users = getAllUsers();
    let sent = 0, failed = 0;
    await bot.sendMessage(chatId, `⏳ ${users.length} ta foydalanuvchiga yuborilmoqda...`);
    for (const user of users) {
      try {
        await bot.sendMessage(user.chatId,
          `📢 <b>Yangilik:</b>\n\n${esc(text)}`,
          { parse_mode: "HTML" });
        sent++;
        await new Promise((r) => setTimeout(r, 60));
      } catch { failed++; }
    }
    await bot.sendMessage(chatId, `✅ Yuborildi: ${sent} ta\n❌ Xato: ${failed} ta`);
  });

  // ─── Rasm yaratish (asosiy) ───────────────────────────────────────────────
  bot.on("message", async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;
    if (!text || text.startsWith("/")) return;

    const user = getOrCreateUser(chatId, msg.from?.username ?? "", msg.from?.first_name ?? "");

    const { ok, notJoined } = await checkChannelSubscriptions(bot, chatId);
    if (!ok) {
      const channels = getRequiredChannels();
      const links = notJoined.map((u) => {
        const ch = channels.find((c) => c.username === u);
        return `  ┣ <a href="https://t.me/${esc(u.replace("@", ""))}">${esc(ch?.name ?? u)}</a>`;
      }).join("\n");
      await bot.sendMessage(chatId,
        `╔══════════════════╗\n` +
        `  ⚠️ <b>A'ZOLIK TALAB</b>\n` +
        `╚══════════════════╝\n\n` +
        `Rasm yaratish uchun quyidagi kanallarga a'zo bo'ling:\n\n` +
        `${links}\n\n` +
        `A'zo bo'lgandan keyin qayta yuboring.`,
        { parse_mode: "HTML", disable_web_page_preview: true });
      return;
    }

    if (user.imageCount <= 0) {
      await bot.sendMessage(chatId,
        `╔══════════════════╗\n` +
        `  ❌ <b>BALANS TUGADI</b>\n` +
        `╚══════════════════╝\n\n` +
        `Sizning rasm imkoniyatingiz tugadi.\n\n` +
        `🔑 Promo-kod bilan to'ldiring:\n` +
        `┗ /code XXXXX\n\n` +
        `Promo-kod olish uchun admin bilan bog'laning.`,
        { parse_mode: "HTML" });
      return;
    }

    let statusMsg: TelegramBot.Message | null = null;

    try {
      statusMsg = await bot.sendMessage(chatId,
        `╔══════════════════╗\n` +
        `   🔄 <b>ISHLOV BERILMOQDA</b>\n` +
        `╚══════════════════╝\n\n` +
        `📝 So'rov: <i>"${esc(text)}"</i>\n\n` +
        `⏳ Tarjima qilinmoqda...`,
        { parse_mode: "HTML" });

      const englishPrompt = await translateUzbekToEnglish(text);
      logger.info({ uzbek: text, english: englishPrompt }, "Translated prompt");

      await bot.editMessageText(
        `╔══════════════════╗\n` +
        `   🎨 <b>RASM YARATILMOQDA</b>\n` +
        `╚══════════════════╝\n\n` +
        `📝 So'rov: <i>"${esc(text)}"</i>\n` +
        `🔤 Tarjima: <i>"${esc(englishPrompt)}"</i>\n\n` +
        `⏳ Iltimos kuting... (30–90 soniya)\n` +
        `🖼  Sifat: flux-pro · 1280×1280`,
        { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" });

      const imageBuffer = await generateImage(englishPrompt);
      decrementUserImages(chatId);
      const updatedUser = getUser(chatId);
      const fileSizeMB = (imageBuffer.length / 1024 / 1024).toFixed(2);
      const bar = balanceBar(updatedUser?.imageCount ?? 0);

      await bot.sendPhoto(
        chatId,
        imageBuffer,
        {
          caption:
            `🎨 <b>Rasm tayyor!</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `📝 So'rov:  <i>${esc(text)}</i>\n` +
            `🔤 Tarjima: <i>${esc(englishPrompt)}</i>\n` +
            `━━━━━━━━━━━━━━━━━━\n` +
            `📦 Hajmi: ${fileSizeMB} MB\n` +
            `${bar}\n` +
            `🖼  Qolgan: <b>${updatedUser?.imageCount ?? 0} ta rasm</b>`,
          parse_mode: "HTML",
        },
        { filename: "rasim.jpg", contentType: "image/jpeg" },
      );

      await bot.deleteMessage(chatId, statusMsg.message_id);
    } catch (err) {
      logger.error({ err }, "Error generating image");
      const errMsg = err instanceof Error ? err.message : "Noma'lum xato";
      const errText =
        `╔══════════════════╗\n` +
        `      ❌ <b>XATO</b>\n` +
        `╚══════════════════╝\n\n` +
        `${esc(errMsg)}\n\n` +
        `Iltimos qaytadan urinib ko'ring.`;
      if (statusMsg) {
        await bot.editMessageText(errText, {
          chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "HTML" });
      } else {
        await bot.sendMessage(chatId, errText, { parse_mode: "HTML" });
      }
    }
  });

  bot.on("polling_error", (err) => {
    logger.error({ err }, "Telegram polling error");
  });
}
