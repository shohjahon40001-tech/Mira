# 🎨 Rassom Mira Bot (@rassom_mira_bot)

O'zbek tilida tavsif yuboring — yuqori sifatli AI rasm yaratadi!

## Talablar
- Node.js 20+
- Telegram Bot Token (@BotFather)
- Admin ID raqami

## O'rnatish & Run

```bash
npm install
npm run build
npm start
```

## Environment (.env)
```
TELEGRAM_BOT_TOKEN=xxxxx
ADMIN_CHAT_ID=xxxxx
PORT=3000
NODE_ENV=production
```

## Xususiyatlar
- O'zbek → Ingliz tarjima (bepul)
- AI rasm yaratish (bepul)
- Navbat tizimi + retry logic
- Admin panel + promo-kodlar
- Channel a'zolik tekshiruvi
- Foydalanuvchi statistikasi

## Deploy (Railway)
1. GitHub reposini ulab oling
2. Railway'da new project yarating
3. .env qo'shing
4. Deploy bosing — tugadi! 🚀
