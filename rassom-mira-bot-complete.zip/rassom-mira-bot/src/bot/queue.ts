type Task = () => Promise<void>;

class ImageQueue {
  private running = 0;
  private readonly maxConcurrent = 2;
  private queue: Array<{ task: Task; resolve: () => void; reject: (e: unknown) => void }> = [];

  async add(task: Task): Promise<void> {
    return new Promise((resolve, reject) => {
      this.queue.push({ task, resolve, reject });
      this.process();
    });
  }

  private async process(): Promise<void> {
    if (this.running >= this.maxConcurrent || this.queue.length === 0) return;
    const item = this.queue.shift()!;
    this.running++;
    try {
      await item.task();
      item.resolve();
    } catch (e) {
      item.reject(e);
    } finally {
      this.running--;
      this.process();
    }
  }

  get size(): number {
    return this.queue.length;
  }
}

export const imageQueue = new ImageQueue();

const userCooldowns = new Map<number, number>();
const COOLDOWN_MS = 15_000;

export function checkUserCooldown(chatId: number): { ok: boolean; remainingSec: number } {
  const last = userCooldowns.get(chatId);
  if (!last) return { ok: true, remainingSec: 0 };
  const elapsed = Date.now() - last;
  if (elapsed >= COOLDOWN_MS) return { ok: true, remainingSec: 0 };
  return { ok: false, remainingSec: Math.ceil((COOLDOWN_MS - elapsed) / 1000) };
}

export function setUserCooldown(chatId: number): void {
  userCooldowns.set(chatId, Date.now());
}
