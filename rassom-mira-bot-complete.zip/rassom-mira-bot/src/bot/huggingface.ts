import axios from "axios";
import { logger } from "../lib/logger.js";

const MAX_FILE_SIZE = 25 * 1024 * 1024;

const QUALITY_TAGS =
  "masterpiece, best quality, ultra detailed, sharp focus, professional photography, cinematic lighting, 8k";

const NEG_TAGS = encodeURIComponent(
  "blurry, low quality, ugly, distorted, watermark, text, logo, nsfw",
);

const MODELS = ["flux", "flux-realism", "turbo"];

async function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

export async function translateUzbekToEnglish(text: string): Promise<string> {
  try {
    const response = await axios.get<{
      responseData: { translatedText: string };
      responseStatus: number;
    }>("https://api.mymemory.translated.net/get", {
      params: { q: text, langpair: "uz|en" },
      timeout: 15000,
    });

    const translated = response.data?.responseData?.translatedText;
    const status = response.data?.responseStatus;
    if (translated && status === 200 && translated.toLowerCase() !== text.toLowerCase()) {
      return translated;
    }
    return text;
  } catch (err) {
    logger.warn({ err }, "Translation failed, using original text");
    return text;
  }
}

async function tryGenerateImage(prompt: string, model: string): Promise<Buffer> {
  const encodedPrompt = encodeURIComponent(`${prompt}, ${QUALITY_TAGS}`);
  const seed = Math.floor(Math.random() * 9_999_999);
  const url =
    `https://image.pollinations.ai/prompt/${encodedPrompt}` +
    `?width=1024&height=1024` +
    `&model=${model}` +
    `&nologo=true` +
    `&enhance=true` +
    `&negative=${NEG_TAGS}` +
    `&seed=${seed}`;

  logger.info({ model, seed }, "Attempting image generation");

  const response = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 120000,
    headers: { "User-Agent": "RassomMiraBot/3.0" },
    validateStatus: (s) => s < 500,
  });

  if (response.status === 429) {
    throw Object.assign(new Error("rate_limit"), { code: 429 });
  }
  if (response.status !== 200) {
    throw new Error(`Server xatosi: ${response.status}`);
  }

  const buffer = Buffer.from(response.data as ArrayBuffer);

  if (buffer.length < 5000) {
    const text = buffer.toString("utf-8").slice(0, 200);
    throw new Error(`Noto'g'ri javob: ${text}`);
  }
  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error(`Rasm hajmi ${(buffer.length / 1024 / 1024).toFixed(1)}MB dan oshdi`);
  }

  return buffer;
}

export async function generateImage(prompt: string): Promise<Buffer> {
  const maxRetries = 4;
  const delays = [3000, 7000, 15000, 25000];

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const model = MODELS[attempt % MODELS.length]!;

    try {
      const buffer = await tryGenerateImage(prompt, model);
      return buffer;
    } catch (err: unknown) {
      const isRateLimit =
        (err instanceof Error && err.message === "rate_limit") ||
        (typeof err === "object" && err !== null && (err as { code?: number }).code === 429);

      const isLast = attempt === maxRetries - 1;

      if (isLast) {
        logger.error({ err, attempt }, "All image generation attempts failed");
        throw new Error(
          "Rasm yaratish vaqtincha mumkin emas. Bir necha daqiqadan keyin qayta urinib ko'ring."
        );
      }

      const delay = delays[attempt] ?? 25000;
      logger.warn(
        { attempt, model, isRateLimit, delay },
        "Image generation failed, retrying..."
      );
      await sleep(delay);
    }
  }

  throw new Error("Rasm yaratib bo'lmadi. Keyinroq urinib ko'ring.");
}
