import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.resolve(__dirname, "../bot-data.json");

export interface UserData {
  chatId: number;
  username: string;
  firstName: string;
  imageCount: number;
  totalUsed: number;
  joinDate: string;
  usedCodes: string[];
}

export interface PromoCode {
  code: string;
  imagesAdded: number;
  usedBy: number | null;
  usedAt: string | null;
  createdAt: string;
}

export interface Channel {
  username: string;
  name: string;
}

export interface BotData {
  users: Record<number, UserData>;
  promoCodes: Record<string, PromoCode>;
  requiredChannels: Channel[];
  adminIds: number[];
}

const DEFAULT_DATA: BotData = {
  users: {},
  promoCodes: {},
  requiredChannels: [],
  adminIds: [],
};

const DEFAULT_IMAGE_COUNT = 10;

function loadData(): BotData {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, "utf-8");
      return JSON.parse(raw) as BotData;
    }
  } catch {}
  return structuredClone(DEFAULT_DATA);
}

function saveData(data: BotData): void {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
}

let _data: BotData = loadData();

export function getUser(chatId: number): UserData | null {
  return _data.users[chatId] ?? null;
}

export function getOrCreateUser(
  chatId: number,
  username: string,
  firstName: string,
): UserData {
  if (!_data.users[chatId]) {
    _data.users[chatId] = {
      chatId,
      username: username || String(chatId),
      firstName: firstName || "Foydalanuvchi",
      imageCount: DEFAULT_IMAGE_COUNT,
      totalUsed: 0,
      joinDate: new Date().toISOString(),
      usedCodes: [],
    };
    saveData(_data);
  }
  return _data.users[chatId]!;
}

export function decrementUserImages(chatId: number): boolean {
  const user = _data.users[chatId];
  if (!user || user.imageCount <= 0) return false;
  user.imageCount -= 1;
  user.totalUsed += 1;
  saveData(_data);
  return true;
}

export function getAllUsers(): UserData[] {
  return Object.values(_data.users);
}

export function createPromoCode(imagesAdded: number = 10): PromoCode {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  const promo: PromoCode = {
    code,
    imagesAdded,
    usedBy: null,
    usedAt: null,
    createdAt: new Date().toISOString(),
  };
  _data.promoCodes[code] = promo;
  saveData(_data);
  return promo;
}

export function usePromoCode(
  code: string,
  chatId: number,
): {
  success: boolean;
  reason?: string;
  imagesAdded?: number;
  newTotal?: number;
} {
  const upper = code.toUpperCase();
  const promo = _data.promoCodes[upper];
  if (!promo) return { success: false, reason: "Kod topilmadi" };
  if (promo.usedBy !== null) return { success: false, reason: "Kod allaqachon ishlatilgan" };

  const user = _data.users[chatId];
  if (!user) return { success: false, reason: "Foydalanuvchi topilmadi" };

  if (user.usedCodes.includes(upper)) {
    return { success: false, reason: "Siz bu kodni avval ishlatgansiz" };
  }

  promo.usedBy = chatId;
  promo.usedAt = new Date().toISOString();
  user.imageCount += promo.imagesAdded;
  user.usedCodes.push(upper);
  saveData(_data);
  return { success: true, imagesAdded: promo.imagesAdded, newTotal: user.imageCount };
}

export function getRequiredChannels(): Channel[] {
  return _data.requiredChannels;
}

export function addChannel(username: string, name: string): boolean {
  const norm = username.startsWith("@") ? username : `@${username}`;
  if (_data.requiredChannels.find((c) => c.username === norm)) return false;
  _data.requiredChannels.push({ username: norm, name });
  saveData(_data);
  return true;
}

export function removeChannel(username: string): boolean {
  const norm = username.startsWith("@") ? username : `@${username}`;
  const len = _data.requiredChannels.length;
  _data.requiredChannels = _data.requiredChannels.filter(
    (c) => c.username !== norm,
  );
  saveData(_data);
  return _data.requiredChannels.length < len;
}

export function isAdmin(chatId: number): boolean {
  const envId = process.env["ADMIN_CHAT_ID"];
  if (envId && Number(envId) === chatId) return true;
  return _data.adminIds.includes(chatId);
}

export function addAdmin(chatId: number): void {
  if (!_data.adminIds.includes(chatId)) {
    _data.adminIds.push(chatId);
    saveData(_data);
  }
}

export function getStats(): {
  totalUsers: number;
  totalImages: number;
  totalCodes: number;
  usedCodes: number;
} {
  const users = Object.values(_data.users);
  return {
    totalUsers: users.length,
    totalImages: users.reduce((s, u) => s + u.totalUsed, 0),
    totalCodes: Object.keys(_data.promoCodes).length,
    usedCodes: Object.values(_data.promoCodes).filter((p) => p.usedBy !== null).length,
  };
}
